$(document).ready(function () {
    $('#strUserNames').keyup(function () {
        searchUser();
    });
});

function searchUser()
{
    var param1 = $('#strUserNames').val();

    $.ajax({
        url: 'searchUser.jsp',
        method: 'POST',
        data: {
            paramSearch: param1
        },
        success: function (response) {
//                        console.log(response);
            document.getElementById("dResult").innerHTML = response;
        },
        error: function (xhr, status, error) {
//                        console.log(error);
        }
    });
}

//$(document).ready(function () {
//    $('#strUserName').keyup(function () {
//        searchData();
//    });
//});

function searchDataJson()
{

    var param1 = $('#strUserName').val();
    $.ajax({
        url: 'checkUser.jsp',
        method: 'POST',
        data: {
            paramSearch: param1
        },
        success: function (response) {
//            document.getElementById("uResult").innerHTML = response;
            var object = JSON.parse(response);
//                        console.log(object);
            //alert(object.lblName);
            if (object.rstCustomerChecking[0].lblResponse == "AE") {
//                alert("ddd");
                document.getElementById("dMsg").innerHTML = object.rstCustomerChecking[0].lblMessage;
                document.getElementById("hdnValidCust").value = object.rstCustomerChecking[0].lblResponse;
                object = "";
            } else {
                document.getElementById("dMsg").innerHTML = object.rstCustomerChecking[0].lblMessage;
                document.getElementById("hdnValidCust").value = object.rstCustomerChecking[0].lblResponse;
                object = "";
            }
        },
        error: function (xhr, status, error) {
//                        console.log(error);
        }
    });
}

function  getValidateCust() {

    if (document.getElementById("hdnValidCust").value == "AE") {
        alert("Plese Enter Different Customer Name");
        return false;
    }

    if (document.getElementById("strUserName").value == "") {
        alert("Plese Enter Customer Name");
        return false;
    }
    if (document.getElementById("strUserDescription").value == "") {
        alert("Plese Enter Addess");
        return false;
    }


}
