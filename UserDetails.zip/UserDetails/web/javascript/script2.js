function searchUserCompelete() {
    var param1 = document.getElementById("selUserName").value;
    console.log(param1);
    $.ajax({
        url: 'autofill.jsp',
        method: 'POST',
        data: {
            paramSearch: param1
        },
        success: function (response) {
            var object = JSON.parse(response);
            console.log(object);

            if (object.userDetails[0].optUserCity !== "") {
                document.getElementById("optUserCity").innerText = object.userDetails[0].optUserCity;

            }
            if (object.userDetails[0].strUserDescription !== "") {
                document.getElementById("strUserDescription").innerHTML = object.userDetails[0].strUserDescription;

            }
            object = "";
        },
        error: function (xhr, status, error) {
//                        console.log(error);
        }
    });

}