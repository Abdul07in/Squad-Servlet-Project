package com.pojo;

import com.utility.DBConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author tech1
 */
public class User {

    PreparedStatement pstmt = null;
    private Connection con;
    public Exception ex;
    private String hdnUserId, strUserName, strUserCity, strUserDescription;

    public User() {
        con = DBConnection.makeConnection();
    }

    public Connection getCon() {
        return con;
    }

    public void setCon(Connection con) {
        this.con = con;
    }

    public String getHdnUserId() {
        return hdnUserId;
    }

    public void setHdnUserId(String hdnUserId) {
        this.hdnUserId = hdnUserId;
    }

    public String getStrUserName() {
        return strUserName;
    }

    public void setStrUserName(String strUserName) {
        this.strUserName = strUserName;
    }

    public String getStrUserCity() {
        return strUserCity;
    }

    public void setStrUserCity(String strUserCity) {
        this.strUserCity = strUserCity;
    }

    public String getStrUserDescription() {
        return strUserDescription;
    }

    public void setStrUserDescription(String strUserDescription) {
        this.strUserDescription = strUserDescription;
    }

    public Exception SaveDetails() {

        try {

            if ("null".equals(hdnUserId) || hdnUserId == null || "".equals(hdnUserId) || "null".equals(hdnUserId)) {
                pstmt = con.prepareStatement("insert into userdetails (strUserName ,strUserCity ,strUserDescription) values (?,?,?) ");
                } else {
                pstmt = con.prepareStatement("update userdetails set strUserName = ? ,strUserCity = ? ,strUserDescription = ? where strUserId = " + hdnUserId);
                System.out.println("update userdetails set strUserName = ? ,strUserCity = ? ,strUserDescription = ? where strUserId = " + hdnUserId);
//
//                    System.out.println( "Outside  " +hdnUserId);
            }
//            if(hdnUserId!=null || !"".equals(hdnUserId) || hdnUserId != "null"){
//                pstmt = con.prepareStatement("update userdetails set strUserName = ? ,strUserCity = ? ,strUserDescription = ? where strUserId = " + hdnUserId);
////                System.out.println("update userdetails set strUserName = ? ,strUserCity = ? ,strUserDescription = ? where strUserId = " + hdnUserId);
//
//                    System.out.println( "Outside  " +hdnUserId);
//            }
            pstmt.setString(1, strUserName);
            pstmt.setString(2, strUserCity);
            pstmt.setString(3, strUserDescription);
            pstmt.executeUpdate();
            pstmt.close();

        } catch (Exception e) {
            ex = e;
        }
        return ex;
    }

}
